public class SavingsAccount extends Account {
    private double interestRate;

    public SavingsAccount() {
        super();
    }

    public SavingsAccount(int accountNumber, double interestRate) {
        super(accountNumber);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
public double calcInterest()
{
    return balance * interestRate;
}
public void applyInterest()
{
    double interest = calcInterest();
    System.out.println("interest" +interest);
    deposit(interest);

}
    public  void deposit(double amount)
    {
        if (amount>0) {
            balance += amount;
            System.out.println("your deposited amount is" +amount);


            System.out.println("your current amount is"+amount);
        }
        else
        {
            System.out.println("you cannot deposit negative amount");
        }
    }
    public void widraw(double amount)
    {
        if (amount>0)
        {
            if ((amount )<= balance)
            {
                System.out.println("amount is"+amount);

                balance -= amount;

                System.out.println("balance is"+balance);
            }
        }
        else
        {
            System.out.println("negative amount cannot be widrawn");
        }
    }
}

