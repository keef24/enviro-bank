public class CurrentAccount extends Account
{
    private static  double fee =2.5;
    public CurrentAccount()
    {
        super();
    }
    public CurrentAccount(int accountNumber, double fee)
    {
        super(accountNumber);
        fee = fee;
    }
    public  void deposit(double amount)
    {
        if (amount>0) {
            balance += amount;
            System.out.println("your deposited amount is" +amount);
            balance = fee;
            System.out.println("your fee is" +fee);
            System.out.println("your current amount is"+amount);
        }
        else
        {
            System.out.println("you cannot deposit negative amount");
        }
    }
public void widraw(double amount)
{
    if (amount>0)
    {
if ((amount+fee) <= balance)
{
    System.out.println("amount is"+amount);
    balance -= amount;
    balance -= fee;
    System.out.println("fee is"+fee);
    System.out.println("balance is"+balance);
}
    }
    else
    {
        System.out.println("negative amount cannot be widrawn");
    }
}
        }