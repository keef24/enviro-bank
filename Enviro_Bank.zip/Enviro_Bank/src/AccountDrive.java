import java.util.Scanner;
public class AccountDrive {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Account accounts[] = new Account[20];
    }
    public static int accountMenu(Scanner keyboard)
    {
        System.out.println("select account type");
        System.out.println("1. current account");
        System.out.println("2. savings account");

        int choice;
        do {
            System.out.println("enter choice");
            choice = keyboard.nextInt();
        }
            while (choice < 1 || choice > 2) ;
            return choice;

        }
        public int searchAccount(Account account[],int count, int accountNumber)
        {
            for (int i =0; i <count; i++)
            {
                if (account[i].getAccountNumber() == accountNumber)
                {
                    return  i;
                }
            }
            return  -1;
        }
        public void doDeposit(Account account[],int count, Scanner keyboard) {
            System.out.println("please enetr account number");
            int accountNumber = keyboard.nextInt();

            int index = searchAccount(account, count, accountNumber);
            if (index >= 0) {

                System.out.println("please enter deposit amount");
                double amount = keyboard.nextDouble();
                account[index].deposit(amount);

            } else {
                System.out.println("no account exist with this number" + accountNumber);
            }
        }
        public void doWidraw(Account account[], int count, Scanner keyboard)
        {
            System.out.println("please enter account number");
            int accountNumber = keyboard.nextInt();

            int index = searchAccount(account, count, accountNumber);
            if (index >= 0) {

                System.out.println("please enter widrawal amount");
                double amount = keyboard.nextDouble();
                account[index].widraw(amount);

            } else {
                System.out.println("no account exist with this number" + accountNumber);
            }
        }
        public Account applyInterest(Account[] account, int count, Scanner keyboard) {
            System.out.println("please enter account number");
            int accountNumber = keyboard.nextInt();

            int index = searchAccount(account, count, accountNumber);
            if (index >= 0) {
                if (account[index] instanceof SavingsAccount) {
                    ((SavingsAccount) account[index]).applyInterest();


                } else {
                    System.out.println("no account exist with this number" + accountNumber);
                }
            }
            public static int createAccount (Scanner keyboard)
            {
                Account account = null;
                int choice = accountMenu(keyboard);
                int accountNumbers = 0;
                System.out.println("enter account number");
                accountNumber = keyboard.nextInt();
                if (choice == 1) // current account
                {
                    System.out.println("enter transaction fee");
                    double fee = keyboard.nextDouble();

                    account = new CurrentAccount(accountNumber, fee);

                } else {// savings account
                    System.out.println("enter interest rate");
                    double ir = keyboard.nextDouble();

                    accoun= new SavingsAccount(accountNumbers, ir);
                }
                return accounts;

            }
            public static int menu (Scanner keyboard){
                System.out.println("bank account menu");
                System.out.println("create new account");
                System.out.println("deposit funds");
                System.out.println("widraw funds");
                System.out.println("Quit");

                int choice;
                do {
                    System.out.println("enter choice");
                    choice = keyboard.nextInt();
                }
                while (choice < 1 || choice > 4);

            }
            return choice;
        }

    }

